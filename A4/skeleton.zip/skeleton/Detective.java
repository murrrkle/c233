/** 
 * Detective.java: The detective that reasons about the murder based on information provided 
 *                 and the response from the Oracle. <br>
 * Copyright (c) 2013 Mea Wang. All rights reserved.
 *
 * @author Mea Wang
 * @version CPSC 233, Assignment 4
 */

/*********************************************************
 * Last Name:  
 * First Name: 
 * Student ID: 
 * Course: CPSC 233
 * Tutorial Section:
 * Assignment: 4
 *
 * <Brief description of your program and main features>
*********************************************************/

public class Detective
{
    private Oracle theOracle;
    
    /** Constructor 
     * @param ora The reference to the Oracle 
     */
    public Detective (Oracle ora)
    {
        // Initialize the data members

        theOracle = ora;
    }
    
    public boolean check (String line)
    {
 
        return false;
    }
    
    
    public String toString()
    {
        String str = "";
        
        return str;
    }
}
