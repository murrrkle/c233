/** 
 * Location.java:  A class containing the location information. <br>
 * Copyright (c) 2013 Mea Wang. All rights reserved.
 *
 * @author Mea Wang
 * @version CPSC 233, Assignment 4
 */

/*********************************************************
 * Last Name:  
 * First Name: 
 * Student ID: 
 * Course: CPSC 233
 * Tutorial Section:
 * Assignment: 4
 *
 * <Brief description of your program and main features>
*********************************************************/

public class Location
{
    private double x;
    private double y;
    
    /** Constructor
     * @param p The place
     * @param c The city
     * @param prov The province
     */
    public Location (double xValue, double yValue)
    {
        x = xValue;
        y = yValue;
    }
    
    /** Match the given location with this location
     * @param loc The given location
     * @return The distance between loc and this location
     */
    public double matches (Location loc)
    {
        double distance = 0;
        


        
        return distance;
    }
    
    /** Conver the class object to a string
     * @return The string representatio of the Location object
     */
    public String toString()
    {
        return "(" + Double.toString(x) + ", " + Double.toString(y) + ")";
    }       
}
