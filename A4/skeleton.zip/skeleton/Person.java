/** 
 * Person.java:  A class containing the person information. <br>
 * Copyright (c) 2013 Mea Wang. All rights reserved.
 *
 * @author Mea Wang
 * @version CPSC 233, Assignment 4
 */

/*********************************************************
 * Last Name:  
 * First Name: 
 * Student ID: 
 * Course: CPSC 233
 * Tutorial Section:
 * Assignment: 4
 *
 * <Brief description of your program and main features>
*********************************************************/

public class Person
{
    private char gender;
    private int ageRange;
    private double height;
    
    /** Constructor
     * @param g The gender
     * @param range The age range
     * @param h The height
     */
    public Person (char g, int range, double h)
    {
        gender = g;
        ageRange = range;
        height = h;
    }
    
    /** Match the given person with this person
     * @param individual The given person
     * @return The difference between the individual and this person
     */
    public double matches (Person individual)
    {
        double diff = 0;
        
        return diff;
    }
    
    /** Conver the class object to a string
     * @return The string representatio of the Person object
     */
    public String toString()
    {
        String str = "";
        if (gender == 'F')
            str += "female, ";
        else if (gender == 'M')
            str += "male, ";
        else
            str += "unknown, ";
            
        str += ageRange + "'s, ";
        str += height +"m";
        
        return str;
    }       
}
